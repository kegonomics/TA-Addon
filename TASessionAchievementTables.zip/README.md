TrueAchievements Additamenta
============================

TrueAchievements Additamenta (TAA) is a chrome extension that adds additional features to http://trueachievements.com.

Current features:

  - Gaming Session Achievement Matrix

### Version

0.1 beta

### Tech

TAA uses a number of open source projects to work properly:

* [jQuery 2.1.3](https://jquery.com/)
* [FontAwesome](https://fortawesome.github.io/Font-Awesome/)

### Installation

Features
--------

### Gaming Session Achievement Matrix